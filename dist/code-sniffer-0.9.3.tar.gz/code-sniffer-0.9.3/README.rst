About
-----

This program is intended to be used to check plagiarism in assignments. It is a
poor man's `MOSS <http://theory.stanford.edu/~aiken/moss/>`_.

Usage 
=====

See the project page for more details. `Project page <http://dilawar.github.io/sniffer>`_.

